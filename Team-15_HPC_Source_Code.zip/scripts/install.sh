#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m venv .venv
.venv/bin/python -m pip install -e '.[dev,science]'
.venv/bin/python scripts/build.py --test
printf 'Ready: .venv/bin/hftlab\n'
